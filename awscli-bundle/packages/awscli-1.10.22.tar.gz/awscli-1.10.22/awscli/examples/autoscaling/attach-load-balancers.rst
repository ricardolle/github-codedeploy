**To attach a load balancer to an Auto Scaling group**

This example attaches the specified load balancer to the specified Auto Scaling group::

    aws autoscaling attach-load-balancers --load-balancer-names my-load-balancer --auto-scaling-group-name my-auto-scaling-group
